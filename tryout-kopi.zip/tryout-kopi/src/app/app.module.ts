import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatNativeDateModule} from '@angular/material';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import { RouterModule } from '@angular/router';





import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MessageComponent } from './message/message.component';
import { LoginComponent } from './login/login.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { CreateListComponent } from './create-list/create-list.component';
import { EditListComponent } from './edit-list/edit-list.component';
import { DeleteListComponent } from './delete-list/delete-list.component';
import { Component } from '@angular/core/src/metadata/directives';
import { AlertModule } from 'ngx-bootstrap/alert';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { CarouselModule } from 'ngx-bootstrap/carousel';

const routes = [
  {path: 'login', component: LoginComponent},
  {path: 'message', component: MessageComponent},
  {path: 'create-list', component: CreateListComponent},
  {path: 'delete-list', component: DeleteListComponent},
  {path: 'edit-list', component: EditListComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MessageComponent,
    LoginComponent,
    CreateListComponent,
    EditListComponent,
    DeleteListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatNativeDateModule,
    NgbModule.forRoot(),
    BsDropdownModule.forRoot(),
    RouterModule.forRoot(routes),
    AlertModule.forRoot(),
    TypeaheadModule.forRoot(),
    TooltipModule.forRoot(),
    CarouselModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
