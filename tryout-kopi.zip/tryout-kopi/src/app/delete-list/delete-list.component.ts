import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-list',
  templateUrl: './delete-list.component.html',
  styleUrls: ['./delete-list.component.css']
})
export class DeleteListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
